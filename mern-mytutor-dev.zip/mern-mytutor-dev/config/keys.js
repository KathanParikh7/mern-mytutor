module.exports = {
	mongoURI:
		"mongodb+srv://harrnish:hrndb0000@cluster0.zmxjz.mongodb.net/<dbname>?retryWrites=true&w=majority",
};
